"""
This package includes container-objects which are
used to manage stored data
"""
