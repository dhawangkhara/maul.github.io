"""This package includes extensions with broader usability"""
