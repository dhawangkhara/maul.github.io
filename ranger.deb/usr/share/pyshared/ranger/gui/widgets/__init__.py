from ranger.gui.displayable import Displayable

class Widget(Displayable):
	"""
	The Widget class defines no methods and only exists for
	classification of widgets.
	"""
